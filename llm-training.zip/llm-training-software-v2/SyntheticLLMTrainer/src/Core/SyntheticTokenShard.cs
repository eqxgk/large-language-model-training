using System;
using System.Numerics;

namespace SyntheticLLMTrainer.Optimization
{
    public class MemoryVectorQuantizer
    {
        public Vector<float>[] Quantize(int count = 128, int dim = 8)
        {
            var rand = new Random();
            Vector<float>[] result = new Vector<float>[count];

            for (int i = 0; i < count; i++)
            {
                float[] data = new float[dim];
                for (int j = 0; j < dim; j++)
                    data[j] = (float)(rand.NextDouble() * 2 - 1);
                result[i] = new Vector<float>(data);
            }

            return result;
        }

        public float Measure(Vector<float>[] vectors)
        {
            float score = 0;
            foreach (var v in vectors)
                score += v.Length;
            return score / vectors.Length;
        }
    }
}
