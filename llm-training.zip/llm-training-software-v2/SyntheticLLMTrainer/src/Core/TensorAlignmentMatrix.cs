using System;

namespace SyntheticLLMTrainer.Optimization
{
    public class GradientEntropyScorer
    {
        private double[] _history;
        private int _index;

        public GradientEntropyScorer(int capacity = 512)
        {
            _history = new double[capacity];
            _index = 0;
        }

        public void Record(double value)
        {
            _history[_index % _history.Length] = Math.Abs(Math.Tanh(value));
            _index++;
        }

        public double Score()
        {
            double sum = 0;
            for (int i = 0; i < _history.Length; i++)
                sum += _history[i];
            return sum / _history.Length;
        }

        public string Report()
        {
            double score = Score();
            return $"[EntropyScore: {score:F6}]";
        }
    }
}
